cp wheel_strech.dae ../../Wheel_LR/meshes/
cp wheel_strech.dae ../../Wheel_RF/meshes/
cp wheel_strech.dae ../../Wheel_RR/meshes/